/*
 * main.c
 *
 * Created: 4/13/2024 7:03:53 PM
 *  Author: angel
 */ 

#define F_CPU 16000000
#include <xc.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "PWM0/PMW0.h"
#include "PWM1/PWM1.h"
#include "ADC/ADC.h"
#include "Timer0/Timer0.h"
#include "TIMER2/TIMER2.h"
volatile uint8_t valorADC = 0;
volatile uint8_t valorADC_S = 0;
volatile float valor_reescalado=0;

void init_pines(void){
		// Configurar los pines PC4, PC5 y PC6 como entradas y habilitar resistencias de pull-up
		DDRC &= ~(1 << DDC4) & ~(1 << DDC5) & ~(1 << DDC6);
		PORTC |= (1 << PORTC4) | (1 << PORTC5)| (1 << PORTC6);
		DDRD |= (1 << DDD7);
		sei();

}

float map(uint8_t value, float in_min,float in_max,float out_min, float out_max){
	return (((value*in_min)*(out_max-out_min))/(in_max-in_min))+out_min;
}


// Rutina de servicio de interrupci�n para la comparaci�n  A del Timer0 (CTC)
ISR(TIMER0_COMPA_vect) {
	TIFR0 |= (1 << OCF0A);
}

ISR(TIMER2_COMPA_vect){
	valorADC=readADC(6);
	CTC_Timer0A(valorADC);
	TIFR2 |= (1 << TOIE2);
}

int main() {
	init_pines();
	//frecuencia del adc -> 16M/128 = 125kHz
	init_ADC(0,0,128); 
	
	
	//PWM MANUALMENTE
	
	//INICIAR TIMER0 (DUTY CYCLE)
	init_Timer0(1,1024);
	
	//INICIAR TIMER2 (PERIODO)
	init_Timer2(1,1024);
	CTC_Timer2A(255);

	while (1) {
		if (TCNT2 < OCR0A) {
			PORTD |= (1 << DDD7); // Alto
			} else {
			PORTD &= ~(1 << DDD7); // Bajo
			}
		}

	return 0;
}